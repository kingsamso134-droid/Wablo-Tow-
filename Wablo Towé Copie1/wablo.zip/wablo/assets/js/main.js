document.querySelectorAll('.pw button').forEach(b=>b.addEventListener('click',()=>{
  const i=b.parentElement.querySelector('input'),show=i.type==='password';
  i.type=show?'text':'password';b.textContent=show?'Masquer':'Afficher';b.setAttribute('aria-pressed',show);
}));
const pw=document.querySelector('[data-pw]');
if(pw){const rules=document.querySelectorAll('.rules li'),tests=[v=>v.length>=8,v=>/[A-Za-z]/.test(v),v=>/\d/.test(v)];
  pw.addEventListener('input',()=>rules.forEach((li,k)=>li.classList.toggle('ok',tests[k](pw.value))));}
document.querySelectorAll('form[data-validate]').forEach(f=>f.addEventListener('submit',e=>{
  let bad=false;
  f.querySelectorAll('[required]').forEach(i=>{const ko=!i.checkValidity();i.setAttribute('aria-invalid',ko);if(ko)bad=true;});
  const c=f.querySelector('[data-confirm]');
  if(pw&&c){const ko=pw.value!==c.value;c.setAttribute('aria-invalid',ko);if(ko)bad=true}
  if(bad){e.preventDefault();f.querySelector('[aria-invalid=true]').focus()}
}));
const m=document.getElementById('msg');if(m)m.addEventListener('input',()=>{const n=m.value.length;document.getElementById('count').textContent=n+(n>1?' caractères':' caractère')});
const ra=document.getElementById('readall');if(ra)ra.addEventListener('click',()=>{document.querySelectorAll('.unread').forEach(e=>e.classList.remove('unread'));document.querySelectorAll('.note-i small b').forEach(e=>e.remove());document.querySelectorAll('.bell i').forEach(e=>e.remove())});
const ad=document.getElementById('add');if(ad)ad.addEventListener('click',()=>{const n=prompt('Titre du chapitre');if(n){const d=document.createElement('div');d.className='pn';d.innerHTML='<span></span><span class="badge">Chapitre propre</span>';d.firstChild.textContent='☰ '+n;document.getElementById('chap').append(d)}});
